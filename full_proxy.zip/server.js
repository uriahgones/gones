const http = require('http');
const express = require('express');
const httpProxy = require('http-proxy');
const morgan = require('morgan');
const { HttpsProxyAgent } = require('https-proxy-agent');
const zlib = require('zlib');

const TARGET = process.env.TARGET_ORIGIN || 'https://sepolia-faucet.pk910.de';
const UPSTREAM_PROXY = process.env.UPSTREAM_PROXY || null;
const PORT = parseInt(process.env.PORT || '80', 10);

if (!TARGET) {
  console.error('TARGET not set');
  process.exit(1);
}

console.log('🚀 Starting full reverse proxy');
console.log('→ Target:', TARGET);
if (UPSTREAM_PROXY) console.log('→ Upstream Proxy:', UPSTREAM_PROXY);

const agent = UPSTREAM_PROXY ? new HttpsProxyAgent(UPSTREAM_PROXY) : undefined;

const proxy = httpProxy.createProxyServer({
  target: TARGET,
  changeOrigin: true,
  ws: true,
  secure: true,
  agent
});

proxy.on('error', (err, req, res) => {
  console.error('Proxy error:', err && err.message);
  try {
    if (!res.headersSent) res.writeHead(502, {'Content-Type': 'text/plain'});
    res.end('Bad gateway');
  } catch (e) {}
});

function shouldRewrite(headers) {
  const ct = (headers['content-type'] || '').toLowerCase();
  return ct.includes('text/html') || ct.includes('application/javascript') || ct.includes('text/javascript') || ct.includes('application/json') || ct.includes('text/css');
}

function gunzipIfNeeded(buffer, encoding) {
  if (!encoding) return buffer;
  encoding = encoding.toLowerCase();
  if (encoding.includes('gzip')) return zlib.gunzipSync(buffer);
  if (encoding.includes('deflate')) return zlib.inflateSync(buffer);
  return buffer;
}

function gzipIfNeeded(buffer, encoding) {
  if (!encoding) return buffer;
  encoding = encoding.toLowerCase();
  if (encoding.includes('gzip')) return zlib.gzipSync(buffer);
  if (encoding.includes('deflate')) return zlib.deflateSync(buffer);
  return buffer;
}

const app = express();
app.use(morgan('combined'));

// health & check-ip
app.get('/healthz', (_req, res) => res.send('ok'));
app.get('/check-ip', async (req, res) => {
  const fetch = require('node-fetch');
  try {
    const r = await fetch('https://api.ipify.org?format=json', { agent });
    const j = await r.json();
    res.json({ outgoing_ip: j.ip, upstream_proxy: !!UPSTREAM_PROXY });
  } catch (e) {
    res.status(500).json({ error: 'check-ip-failed', message: e.message });
  }
});

// main proxy handler
app.use((req, res) => {
  delete req.headers['x-forwarded-for'];
  delete req.headers['x-real-ip'];

  proxy.web(req, res, { target: TARGET }, (e) => {
    console.error('Proxy web error fallback:', e && e.message);
  });
});

// intercept proxy responses to rewrite body and headers
proxy.on('proxyRes', function (proxyRes, req, res) {
  try {
    // Rewrite Location header if redirect
    if (proxyRes.headers && proxyRes.headers['location']) {
      const myHost = req.headers.host;
      proxyRes.headers['location'] = proxyRes.headers['location'].replace(TARGET, 'http://' + myHost);
    }

    const headers = proxyRes.headers || {};
    if (!shouldRewrite(headers)) return;

    let bodyChunks = [];
    proxyRes.on('data', chunk => bodyChunks.push(chunk));
    proxyRes.on('end', () => {
      try {
        const encoding = headers['content-encoding'];
        let buf = Buffer.concat(bodyChunks || []);
        buf = gunzipIfNeeded(buf, encoding);
        let text = buf.toString('utf8');

        // Replace target URL with VPS host
        const upstreamHost = TARGET.replace(/^https?:\/\//, '').replace(/\/$/, '');
        const myHost = req.headers.host;
        const regex = new RegExp('https?:\\/\\/' + upstreamHost.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&'), 'g');
        text = text.replace(regex, 'http://' + myHost);
        // Also catch bare domain references
        const bareRegex = new RegExp(upstreamHost.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&'), 'g');
        text = text.replace(bareRegex, myHost);

        let outBuf = Buffer.from(text, 'utf8');
        outBuf = gzipIfNeeded(outBuf, encoding);

        Object.keys(headers).forEach(name => {
          if (name.toLowerCase() === 'content-length') return;
          if (name.toLowerCase() === 'content-encoding') res.setHeader(name, headers[name]);
          else res.setHeader(name, headers[name]);
        });
        res.setHeader('content-length', outBuf.length);
        res.writeHead(proxyRes.statusCode, proxyRes.statusMessage, res.getHeaders());
        res.end(outBuf);
      } catch (err) {
        console.error('rewrite error:', err && err.message);
      }
    });
  } catch (e) {
    console.error('proxyRes handler error', e && e.message);
  }
});

const server = http.createServer(app);
server.on('upgrade', (req, socket, head) => {
  proxy.ws(req, socket, head, { target: TARGET, agent });
});

server.listen(PORT, () => {
  console.log(`✅ Reverse proxy listening on :${PORT}`);
});
