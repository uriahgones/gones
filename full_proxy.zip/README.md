Full reverse rewrite proxy (public) - README

Files included:
- server.js      : full reverse proxy that rewrites HTML/JS/CSS and Location headers to keep clients on VPS host
- package.json
- Dockerfile

Build:
  docker build -t reverse-rewrite-full-proxy .

Run (single port):
  docker run -d --name reverse-rewrite     -p 80:80     -e TARGET_ORIGIN="https://sepolia-faucet.pk910.de"     -e UPSTREAM_PROXY="http://user:pass@gw.dataimpulse.com:10001"     reverse-rewrite-full-proxy

Run (multi-user, different ports):
  docker run -d --name reverse-rewrite-1 -p 8001:80 -e TARGET_ORIGIN="https://sepolia-faucet.pk910.de" -e UPSTREAM_PROXY="http://user:pass@gw.dataimpulse.com:10001" reverse-rewrite-full-proxy
  docker run -d --name reverse-rewrite-2 -p 8002:80 -e TARGET_ORIGIN="https://sepolia-faucet.pk910.de" -e UPSTREAM_PROXY="http://user:pass@gw.dataimpulse.com:10001" reverse-rewrite-full-proxy

Test outgoing IP:
  curl -s http://127.0.0.1/check-ip

Health check:
  curl -s http://127.0.0.1/healthz
