# Selenium Relay Proxy (Node.js)

Simple reverse proxy so your GitLab runner only connects to **your** relay,
while the relay forwards traffic to the upstream site.

## Quick start (HTTP)
```bash
docker build -t relay-proxy .
docker run -d --name relay -p 8080:8080 --env TARGET_ORIGIN=https://sepolia-faucet.pk910.de relay-proxy
# Health check
curl http://localhost:8080/healthz
```

Then point Selenium to: `http://<your-server>:8080/#/mine/<ID>`

## Production TLS (option A: Caddy in front)
Use Caddy (or Nginx) as TLS terminator and reverse_proxy to this container:
```
your-relay.example.com {
    reverse_proxy 127.0.0.1:8080
}
```
Caddy will auto-issue HTTPS certificates.

## Environment variables
- `TARGET_ORIGIN` (required) e.g., `https://sepolia-faucet.pk910.de`
- `PRESERVE_HOST` (optional, default false)
- `PORT` (optional, default 8080)

## Notes
- URL fragments (the part after `#`) are **not sent to the server**, but the browser keeps them and the SPA will work normally through the proxy.
- To rotate relays, deploy multiple relay instances and load-balance them.
