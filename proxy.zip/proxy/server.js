const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');
const morgan = require('morgan');
const helmet = require('helmet');
const compression = require('compression');
const dotenv = require('dotenv');

dotenv.config();

const app = express();

const target = process.env.TARGET_ORIGIN; // e.g., https://sepolia-faucet.pk910.de
if (!target) {
  console.error("ERROR: TARGET_ORIGIN not set");
  process.exit(1);
}

// Basic hardening & logging
app.use(helmet({
  contentSecurityPolicy: false, // let upstream handle CSP
}));
app.use(compression());
app.use(morgan('combined'));

// Health check
app.get('/healthz', (req, res) => res.send('ok'));

// Proxy everything to target (preserve host optional)
const preserveHost = (process.env.PRESERVE_HOST || 'false').toLowerCase() === 'true';

app.use('/', createProxyMiddleware({
  target,
  changeOrigin: !preserveHost,
  xfwd: true,
  ws: true, // websocket support
  secure: true, // verify upstream TLS
  proxyTimeout: 120000,
  timeout: 120000,
  onProxyReq: (proxyReq, req, res) => {
    // strip any identifying headers you don't want leaving the runner
    proxyReq.removeHeader('X-Forwarded-For');
    proxyReq.removeHeader('Via');
  },
  onError: (err, req, res) => {
    res.status(502).send('Proxy error');
  }
}));

const port = process.env.PORT || 8080;
app.listen(port, () => {
  console.log(`Relay proxy listening on :${port}, forwarding to ${target}`);
});
