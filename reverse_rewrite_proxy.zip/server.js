// server.js
const http = require('http');
const express = require('express');
const httpProxy = require('http-proxy');
const morgan = require('morgan');
const { HttpsProxyAgent } = require('https-proxy-agent');
const zlib = require('zlib');

const TARGET = process.env.TARGET_ORIGIN || 'https://sepolia-faucet.pk910.de';
const UPSTREAM_PROXY = process.env.UPSTREAM_PROXY || null; // e.g. http://user:pass@host:port
const PORT = parseInt(process.env.PORT || '80', 10);

if (!TARGET) {
  console.error('TARGET not set');
  process.exit(1);
}

console.log('Starting reverse proxy (HTML rewrite)');
console.log('Target:', TARGET);
if (UPSTREAM_PROXY) console.log('Upstream proxy set');

const agent = UPSTREAM_PROXY ? new HttpsProxyAgent(UPSTREAM_PROXY) : undefined;

const proxy = httpProxy.createProxyServer({
  target: TARGET,
  changeOrigin: true,
  ws: true,
  secure: true,
  agent
});

proxy.on('error', (err, req, res) => {
  console.error('Proxy error:', err && err.message);
  try {
    if (!res.headersSent) res.writeHead(502, {'Content-Type': 'text/plain'});
    res.end('Bad gateway');
  } catch (e) {}
});

// Rewrite HTML (and some JS/CSS) to replace upstream host with our host so browser doesn't redirect
function shouldRewrite(headers) {
  const contentType = (headers['content-type'] || '').toLowerCase();
  return contentType.includes('text/html') || contentType.includes('application/javascript') || contentType.includes('text/javascript') || contentType.includes('application/json') || contentType.includes('text/css');
}

function gunzipIfNeeded(buffer, encoding) {
  if (!encoding) return buffer;
  encoding = encoding.toLowerCase();
  if (encoding.includes('gzip')) return zlib.gunzipSync(buffer);
  if (encoding.includes('deflate')) return zlib.inflateSync(buffer);
  return buffer;
}

function gzipIfNeeded(buffer, encoding) {
  if (!encoding) return buffer;
  encoding = encoding.toLowerCase();
  if (encoding.includes('gzip')) return zlib.gzipSync(buffer);
  if (encoding.includes('deflate')) return zlib.deflateSync(buffer);
  return buffer;
}

const app = express();
app.use(morgan('combined'));

app.get('/healthz', (_req, res) => res.send('ok'));
app.get('/check-ip', async (req, res) => {
  const fetch = require('node-fetch');
  try {
    const response = await fetch('https://api.ipify.org?format=json', { agent });
    const j = await response.json();
    res.json({ outgoing_ip: j.ip, upstream_proxy: !!UPSTREAM_PROXY });
  } catch (e) {
    res.status(500).json({ error: 'check-ip-failed', message: e.message });
  }
});

// main handler: proxy all requests, handle response for rewriting
app.use((req, res) => {
  delete req.headers['x-forwarded-for'];
  delete req.headers['x-real-ip'];

  proxy.web(req, res, { target: TARGET }, (e) => {
    console.error('Proxy web error fallback:', e && e.message);
  });
});

// intercept proxy responses and rewrite if needed
proxy.on('proxyRes', function (proxyRes, req, res) {
  try {
    if (proxyRes.headers && proxyRes.headers['location']) {
      delete proxyRes.headers['location'];
    }

    const headers = proxyRes.headers || {};
    if (!shouldRewrite(headers)) {
      return;
    }

    let bodyChunks = [];
    proxyRes.on('data', chunk => bodyChunks.push(chunk));
    proxyRes.on('end', () => {
      try {
        const encoding = headers['content-encoding'];
        let buf = Buffer.concat(bodyChunks || []);
        buf = gunzipIfNeeded(buf, encoding);
        let text = buf.toString('utf8');

        const upstreamHost = TARGET.replace(/^https?:\/\//, '').replace(/\/$/, '');
        const myHost = req.headers.host;
        const regex = new RegExp('https?:\\/\\/' + upstreamHost.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&'), 'g');
        text = text.replace(regex, (m) => {
          const scheme = req.protocol || (req.headers['x-forwarded-proto'] || 'http');
          return scheme + '://' + myHost;
        });

        const hostRegex = new RegExp(upstreamHost.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&'), 'g');
        text = text.replace(hostRegex, myHost);

        let outBuf = Buffer.from(text, 'utf8');
        outBuf = gzipIfNeeded(outBuf, encoding);

        Object.keys(headers).forEach(name => {
          if (name.toLowerCase() === 'content-length') return;
          if (name.toLowerCase() === 'content-encoding') {
            res.setHeader(name, headers[name]);
            return;
          }
          res.setHeader(name, headers[name]);
        });
        res.setHeader('content-length', outBuf.length);
        res.writeHead(proxyRes.statusCode, proxyRes.statusMessage, res.getHeaders());
        res.end(outBuf);
      } catch (err) {
        console.error('rewrite error:', err && err.message);
      }
    });
  } catch (e) {
    console.error('proxyRes handler error', e && e.message);
  }
});

const server = http.createServer(app);
server.on('upgrade', (req, socket, head) => {
  proxy.ws(req, socket, head, { target: TARGET, agent });
});

server.listen(PORT, () => {
  console.log(`Reverse proxy listening on :${PORT}`);
});
