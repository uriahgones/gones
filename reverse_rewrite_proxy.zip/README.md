Reverse rewrite proxy (public) - README

Files included:
- server.js      : reverse proxy that rewrites HTML/JS content to keep clients on VPS host and forwards outbound via UPSTREAM_PROXY
- package.json
- Dockerfile

Build:
  docker build -t reverse-rewrite-proxy .

Run:
  docker run -d --name reverse-rewrite -p 80:80 \\
    -e TARGET_ORIGIN=https://sepolia-faucet.pk910.de \\
    -e UPSTREAM_PROXY="http://user:pass@gw.dataimpulse.com:10001" \\
    reverse-rewrite-proxy

Test outgoing IP:
  curl -s http://127.0.0.1/check-ip
Health:
  curl -s http://127.0.0.1/healthz
