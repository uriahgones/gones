# Public Relay Proxy (Upstream Proxy + WebSocket)

This container exposes a public reverse proxy that forwards traffic to a fixed target
and forces all **outbound** connections through an upstream proxy (HTTP/HTTPS/SOCKS).
It also supports WebSockets.

## Build
```bash
docker build -t relay-public .
```

## Run on port 80 (public)
```bash
docker run -d --name relay-public   -p 80:8080   -e TARGET_ORIGIN=https://sepolia-faucet.pk910.de   -e UPSTREAM_PROXY=http://USER:PASS@HOST:PORT   relay-public
```

Replace `UPSTREAM_PROXY` with your residential/mobile proxy, e.g.:
```
http://baf373e3ba6bf985d3d9__cr.us:1d3220777024e30d@gw.dataimpulse.com:10001
```

## Health check
```
curl http://<your-ip-or-domain>/healthz
```

## Notes
- All visitors use the same port (80); the proxy handles multiple users concurrently.
- `TARGET_ORIGIN` defaults to `https://sepolia-faucet.pk910.de` if not set.
- Supports `UPSTREAM_PROXY` schemes: `http://`, `https://`, `socks://`, `socks5://`.
- For HTTPS on your domain, put Caddy/Nginx in front and reverse-proxy to this container.
