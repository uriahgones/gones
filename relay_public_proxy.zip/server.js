// server.js
const http = require('http');
const express = require('express');
const httpProxy = require('http-proxy');
const { ProxyAgent } = require('proxy-agent');
const morgan = require('morgan');

const TARGET_ORIGIN = process.env.TARGET_ORIGIN || 'https://sepolia-faucet.pk910.de';
const UPSTREAM_PROXY = process.env.UPSTREAM_PROXY || null;
const PORT = parseInt(process.env.PORT || '8080', 10);

if (!TARGET_ORIGIN) {
  console.error('❌ TARGET_ORIGIN is required');
  process.exit(1);
}

console.log('🚀 Starting public relay');
console.log('→ Target:', TARGET_ORIGIN);
if (UPSTREAM_PROXY) console.log('→ Upstream Proxy:', UPSTREAM_PROXY);

const agent = UPSTREAM_PROXY ? new ProxyAgent(UPSTREAM_PROXY) : undefined;

// Create proxy server with WebSocket support
const proxy = httpProxy.createProxyServer({
  target: TARGET_ORIGIN,
  changeOrigin: true,
  secure: true,    // verify upstream TLS
  ws: true,
  agent
});

// Optional: set headers before sending
proxy.on('proxyReq', (proxyReq, req, res, options) => {
  if (!proxyReq.getHeader('user-agent')) {
    proxyReq.setHeader('user-agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115 Safari/537.36');
  }
});

proxy.on('error', (err, req, res) => {
  console.error('❌ Proxy error:', err.message);
  try {
    if (!res.headersSent) {
      res.writeHead(502, { 'Content-Type': 'text/plain' });
    }
    res.end('Bad gateway');
  } catch (e) {}
});

const app = express();
app.use(morgan('combined'));

// Healthcheck
app.get('/healthz', (_req, res) => res.send('ok'));

// Forward all routes
app.use((req, res) => {
  proxy.web(req, res);
});

// Create HTTP server to support WS upgrades
const server = http.createServer(app);
server.on('upgrade', (req, socket, head) => {
  proxy.ws(req, socket, head);
});

server.listen(PORT, () => {
  console.log(`✅ Relay listening on :${PORT} (public). All outbound goes via upstream proxy if set.`);
});
